import"./modulepreload-polyfill.js";import{g as u,s as c}from"./storage.js";let e;const a=n("custom-terms"),r=n("trusted-sites"),m=n("save"),i=n("saved-message");d();async function d(){e=await u(),a.value=e.customTerms.join(`
`),r.value=e.trustedSites.join(`
`),m.addEventListener("click",()=>{l()})}async function l(){const t={...e,customTerms:o(a.value),trustedSites:o(r.value)};await c(t),e=t,i.textContent="Saved.",window.setTimeout(()=>{i.textContent=""},1800)}function o(t){return t.split(`
`).map(s=>s.trim()).filter(Boolean)}function n(t){const s=document.getElementById(t);if(!s)throw new Error(`Missing expected element #${t}`);return s}
