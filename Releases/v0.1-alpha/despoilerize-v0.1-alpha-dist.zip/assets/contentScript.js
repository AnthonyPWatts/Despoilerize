(function(){"use strict";const T={id:"f1",label:"Formula 1",entities:["f1","formula 1","formula one","grand prix","gp","qualifying","sprint race","sprint","race","paddock","grid","fia","verstappen","norris","hamilton","piastri","leclerc","russell","alonso","sainz","tsunoda","bearman","antonelli","lawson","hadjar","hulkenberg","ocon","gasly","stroll","albon","bortoleto","red bull","mclaren","ferrari","mercedes","aston martin","williams","haas","sauber","racing bulls","alpine"],spoilerTerms:["wins","won","winner","victory","takes victory","podium","pole","takes pole","p1","p2","p3","dnf","crash","crashes","crashed","safety car","red flag","penalty","fastest lap","championship lead","constructors","drivers' standings","driver standings","race result","results","classified"],safeTerms:["preview","schedule","what time","start time","watch","channel","practice"],regexes:["\\bP[1-9]\\b","\\bDNF\\b"]},k={id:"football",label:"Football",entities:["football","premier league","championship","fa cup","league cup","champions league","europa league","coventry city","sky blues","england"],spoilerTerms:["wins","won","winner","beat","beats","beaten","defeat","defeats","defeated","lose","loses","lost","draw","drew","equaliser","penalty shootout","knocked out","stunned","comeback","injury-time","stoppage-time","full-time","ft","score","result","promoted","relegated","title"],safeTerms:["preview","fixtures","schedule","what time","watch","team news"],regexes:["\\b\\d{1,2}\\s*[-–:]\\s*\\d{1,2}\\b"]},q={[T.id]:T,[k.id]:k};function G(e){return e.map(t=>q[t]).filter(Boolean)}const m={catchUpMode:{enabled:!1,sensitivity:"lockdown"},enabledPacks:["f1"],customTerms:[],trustedSites:[]},C="despoilerze.settings";async function L(){const t=(await chrome.storage.sync.get(C))[C];return{...m,...t,catchUpMode:{...m.catchUpMode,...t?.catchUpMode??{}},enabledPacks:t?.enabledPacks??m.enabledPacks,customTerms:t?.customTerms??m.customTerms,trustedSites:t?.trustedSites??m.trustedSites}}function y(e,t=new Date){return e.catchUpMode.enabled?e.catchUpMode.expiresAtUtc?new Date(e.catchUpMode.expiresAtUtc)>t:!0:!1}const F={gentle:9,balanced:6,lockdown:3};function $(e){return e.toLowerCase().replace(/[‘’]/g,"'").replace(/[“”]/g,'"').replace(/[–—]/g,"-").replace(/\s+/g," ").trim()}function f(e,t){const r=$(t);if(!r)return!1;const n=r.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`(^|[^a-z0-9])${n}([^a-z0-9]|$)`,"i").test(e)}function V(e,t,r,n=[]){const o=$(e),a=[],l=[];let c=0;if(!o||o.length<3)return{shouldHide:!1,score:0,packIds:[],reasons:[],sensitivity:r};for(const i of t){const B=i.entities.filter(d=>f(o,d)),E=i.spoilerTerms.filter(d=>f(o,d)),N=i.safeTerms.filter(d=>f(o,d)),we=i.regexes.filter(d=>new RegExp(d,"i").test(o));if(B.length===0)continue;let p=0;p+=r==="lockdown"?4:3,a.push(`${i.label}: entity match (${B.slice(0,3).join(", ")})`),E.length>0&&(p+=E.length>=2?6:5,a.push(`${i.label}: spoiler wording (${E.slice(0,3).join(", ")})`)),we.length>0&&(p+=6,a.push(`${i.label}: result-like pattern`)),N.length>0&&r!=="lockdown"&&(p-=2,a.push(`${i.label}: possible safe context (${N.slice(0,2).join(", ")})`)),p>0&&(l.push(i.id),c+=p)}const j=n.filter(i=>f(o,i));return j.length>0&&(c+=r==="lockdown"?4:3,a.push(`Custom term match (${j.slice(0,3).join(", ")})`)),{shouldHide:c>=F[r],score:c,packIds:l,reasons:a,sensitivity:r}}const M="despoilerze-shell",w="despoilerze-wrapper",v="despoilerze-blurred",x="despoilerze-overlay",R="data-despoilerze-processed",h="data-despoilerze-hidden",A="data-despoilerze-shell",u="data-despoilerze-target-id",P="data-despoilerze-detached-overlay",W="data-despoilerze-revealed";let Y=1;function Z(){if(document.getElementById("despoilerze-style"))return;const e=document.createElement("style");e.id="despoilerze-style",e.textContent=`
    .${M} {
      display: block !important;
      width: 100% !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
      margin: 0 !important;
      padding: 0 !important;
    }

    .${w} {
      outline: 2px solid rgba(255, 255, 255, 0.22) !important;
      border-radius: 8px !important;
      overflow: hidden !important;
    }

    .${v} {
      filter: blur(10px) !important;
      user-select: none !important;
      pointer-events: none !important;
    }

    .${x} {
      display: block !important;
      position: static !important;
      z-index: 2147483647 !important;
      pointer-events: auto !important;
      padding: 0 !important;
      margin: 0 0 8px 0 !important;
      box-sizing: border-box !important;
      color: #fff !important;
      font-family: system-ui, -apple-system, Segoe UI, sans-serif !important;
      text-align: left !important;
      transform: none !important;
      filter: none !important;
      direction: ltr !important;
      writing-mode: horizontal-tb !important;
    }

    .despoilerze-detached-overlay {
      position: absolute !important;
      z-index: 2147483647 !important;
      display: block !important;
      pointer-events: auto !important;
      padding: 0 !important;
      margin: 0 !important;
      box-sizing: border-box !important;
      transform: none !important;
      filter: none !important;
      direction: ltr !important;
      writing-mode: horizontal-tb !important;
      text-align: left !important;
      color: #fff !important;
      font-family: system-ui, -apple-system, Segoe UI, sans-serif !important;
    }

    .despoilerze-card {
      display: inline-block !important;
      max-width: min(360px, 100%) !important;
      background: rgba(0, 0, 0, 0.88) !important;
      border: 1px solid rgba(255,255,255,0.28) !important;
      border-radius: 8px !important;
      padding: 10px 12px !important;
      box-shadow: 0 6px 20px rgba(0,0,0,0.35) !important;
      box-sizing: border-box !important;
      color: #fff !important;
    }

    .despoilerze-title {
      font-weight: 700 !important;
      margin-bottom: 4px !important;
      font-size: 14px !important;
      line-height: 1.25 !important;
      color: #fff !important;
    }

    .despoilerze-reason {
      font-size: 12px !important;
      line-height: 1.35 !important;
      opacity: 0.85 !important;
      margin-bottom: 8px !important;
      color: #fff !important;
    }

    .despoilerze-button {
      appearance: none !important;
      border: 1px solid rgba(255,255,255,0.35) !important;
      border-radius: 5px !important;
      padding: 4px 8px !important;
      background: rgba(255,255,255,0.12) !important;
      color: #fff !important;
      cursor: pointer !important;
      font-size: 12px !important;
      line-height: 1.2 !important;
      margin: 0 6px 0 0 !important;
    }

    .despoilerze-button:hover {
      background: rgba(255,255,255,0.24) !important;
    }
  `,document.documentElement.appendChild(e)}function g(e){e.setAttribute(R,"true")}function K(e){return e.getAttribute(R)==="true"}function H(e){return e.getAttribute(h)==="true"||!!e.closest(`[${A}="true"]`)}function Q(e,t){if(H(e)||!e.parentElement)return;if(Z(),ee()){X(e,t);return}const r=document.createElement("div");r.className=M,r.setAttribute(A,"true");const n=D(e,t);e.parentElement.insertBefore(r,e),r.appendChild(n),r.appendChild(e),_(e,t)}function X(e,t){const r=te(e),n=D(e,t);n.classList.add("despoilerze-detached-overlay"),n.setAttribute(P,"true"),n.setAttribute(u,r),J(n,e),document.body.appendChild(n),_(e,t)}function D(e,t){const r=document.createElement("div");return r.className=x,r.innerHTML=`
    <div class="despoilerze-card">
      <div class="despoilerze-title">Possible sports result hidden</div>
      <div class="despoilerze-reason">${re(t.reasons[0]??"Catch-up Mode is active")}</div>
      <button class="despoilerze-button" data-action="reveal-once">Reveal once</button>
      <button class="despoilerze-button" data-action="reveal-all">Reveal all on page</button>
    </div>
  `,r.addEventListener("click",n=>{n.stopPropagation();const o=n.target;if(!(o instanceof HTMLElement))return;const l=o.closest("button[data-action]")?.getAttribute("data-action");if(l==="reveal-once"){U(e);return}l==="reveal-all"&&I()}),r}function _(e,t){e.classList.add(w,v),e.setAttribute(h,"true"),e.setAttribute("data-despoilerze-score",String(t.score)),e.setAttribute("data-despoilerze-reasons",t.reasons.join(" | "))}function J(e,t){const r=t.getBoundingClientRect(),n=Math.max(0,r.top+window.scrollY+8),o=Math.max(0,r.left+window.scrollX+8);e.style.top=`${n}px`,e.style.left=`${o}px`,e.style.maxWidth=`${Math.max(220,Math.min(360,r.width-16))}px`}function ee(){return/(^|\.)google\./i.test(window.location.hostname)&&window.location.pathname==="/search"}function te(e){const t=e.getAttribute(u);if(t)return t;const r=`despoilerze-target-${Y++}`;return e.setAttribute(u,r),r}function U(e){const t=e.closest(`[${A}="true"]`),r=e.getAttribute(u);if(e.setAttribute(W,"true"),e.classList.remove(w,v),e.removeAttribute(h),r){for(const n of Array.from(document.querySelectorAll(`[${P}="true"][${u}="${r}"]`)))n.remove();e.removeAttribute(u)}if(t?.parentElement){t.parentElement.insertBefore(e,t),t.remove();return}for(const n of Array.from(e.querySelectorAll(`.${x}`)))n.remove()}function I(){for(const e of Array.from(document.querySelectorAll(`[${h}="true"]`)))U(e)}function re(e){return e.replace(/[&<>"']/g,t=>{switch(t){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";case'"':return"&quot;";case"'":return"&#039;";default:return t}})}const O=["article","h1","h2","h3","h4","[role='article']","[data-testid*='post']","[data-testid*='card']","[class*='promo']","[class*='media']","[id='video-title']","[id='video-title-link']","ytd-rich-item-renderer","ytd-rich-grid-media","ytd-video-renderer","ytd-compact-video-renderer","ytd-grid-video-renderer","ytd-reel-item-renderer","ytd-reel-video-renderer","yt-lockup-view-model","ytm-shorts-lockup-view-model"],oe=["article","[role='article']","[data-testid*='post']","[data-testid*='card']","ytd-rich-item-renderer","ytd-rich-grid-media","ytd-video-renderer","ytd-compact-video-renderer","ytd-grid-video-renderer","ytd-reel-item-renderer","ytd-reel-video-renderer","yt-lockup-view-model","ytm-shorts-lockup-view-model","li",".card",".promo",".media",".gs-result",".g"],ne=[".MjjYud",".hlcw0c",".Ww4FFb",".g",".rc"],ie=["nav","header","footer","form","button","select","textarea","input","[role='navigation']","[role='banner']","[role='search']","[role='menubar']","[role='menu']","[aria-label*='breadcrumb' i]","[class*='breadcrumb' i]","[class*='navbar' i]","[class*='nav-' i]","[class*='masthead' i]","#masthead","ytd-masthead","tp-yt-paper-dialog"];function ae(e,t,r=document){if(!y(e)||ge(e))return;const n=se(r);for(const o of n){if(!(o instanceof HTMLElement)||K(o)||H(o))continue;if(b(o)){g(o);continue}if(!he(o))continue;if(o.closest("[data-despoilerze-hidden='true'], [data-despoilerze-shell='true'], [data-despoilerze-revealed='true']")){g(o);continue}const a=me(o);if(!fe(a)){g(o);continue}const l=V(a,t,e.catchUpMode.sensitivity,e.customTerms);if(l.shouldHide){const c=le(o);!c.closest("[data-despoilerze-hidden='true'], [data-despoilerze-shell='true'], [data-despoilerze-revealed='true']")&&!b(c)&&Q(c,l)}g(o)}}function se(e){const t=new Set;e instanceof Element&&pe(e,O)&&t.add(e);for(const r of O)e.querySelectorAll?.(r).forEach(n=>t.add(n));return Array.from(t)}function le(e){if(ue()){const t=ce(e);if(t)return t}for(const t of oe){const r=e.closest(t);if(r instanceof HTMLElement&&!b(r))return r}return e}function ce(e){for(const t of ne){const r=e.closest(t);if(r instanceof HTMLElement&&de(r))return r}return null}function de(e){if(b(e))return!1;const t=e.getBoundingClientRect();if(t.width<120||t.height<40)return!1;const r=Math.max(document.documentElement.clientHeight,window.innerHeight||0);return!(t.height>r*.8)}function ue(){return/(^|\.)google\./i.test(window.location.hostname)&&window.location.pathname==="/search"}function pe(e,t){return t.some(r=>{try{return e.matches(r)}catch{return!1}})}function me(e){const t=e.getAttribute("aria-label")??"",r=e.getAttribute("title")??"",n=e.innerText??e.textContent??"";return`${t} ${r} ${n}`.replace(/\s+/g," ").trim()}function fe(e){return!e||e.length<4||e.length>500?!1:/[a-zA-Z]/.test(e)}function he(e){const t=window.getComputedStyle(e);if(t.display==="none"||t.visibility==="hidden"||t.opacity==="0")return!1;const r=e.getBoundingClientRect();return r.width>20&&r.height>10}function b(e){return ie.some(t=>{try{return!!e.closest(t)}catch{return!1}})}function ge(e){const t=window.location.hostname.toLowerCase();return e.trustedSites.some(r=>t===r.toLowerCase()||t.endsWith(`.${r.toLowerCase()}`))}let s=null,z=!1;async function be(){if(s=await L(),!y(s))return;S(),new MutationObserver(t=>{if(!s||!y(s))return;const r=[];for(const n of t)for(const o of Array.from(n.addedNodes))(o instanceof Element||o instanceof DocumentFragment)&&r.push(o);r.length>0&&ye(r)}).observe(document.body,{childList:!0,subtree:!0})}function S(e=[document]){if(!s)return;const t=G(s.enabledPacks);for(const r of e)ae(s,t,r)}function ye(e=[document]){z||(z=!0,window.setTimeout(()=>{z=!1,S(e)},250))}chrome.runtime.onMessage.addListener((e,t,r)=>((async()=>{if(e?.type==="DESPOILERZE_SETTINGS_CHANGED"){s=await L(),S(),r({ok:!0});return}if(e?.type==="DESPOILERZE_REVEAL_ALL"){I(),r({ok:!0});return}r({ok:!1})})(),!0)),be()})();
