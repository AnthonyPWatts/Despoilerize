(function(){"use strict";const F=["wins","won","winner","victory","takes victory","podium","pole","takes pole","p1","p2","p3","dnf","crash","crashes","crashed","safety car","red flag","penalty","fastest lap","championship lead","constructors","drivers' standings","driver standings","race result","results","classified"],G=["preview","schedule","what time","start time","watch","channel","practice","free practice"],_=["\\bP[1-9]\\b","\\bDNF\\b"],oe={id:"f1",label:"Formula 1",group:"Motorsport",description:"Formula 1 races, qualifying, sprints, drivers, and teams.",entities:["f1","formula 1","formula one","grand prix","gp","qualifying","sprint race","sprint","race","paddock","grid","fia","verstappen","norris","hamilton","piastri","leclerc","russell","alonso","sainz","tsunoda","bearman","antonelli","lawson","hadjar","hulkenberg","ocon","gasly","stroll","albon","bortoleto","red bull","mclaren","ferrari","mercedes","aston martin","williams","haas","sauber","racing bulls","alpine"],spoilerTerms:F,safeTerms:G,regexes:_},ne={id:"motogp",label:"MotoGP",group:"Motorsport",description:"MotoGP races, riders, teams, and championship results.",entities:["motogp","moto gp","motorcycle grand prix","marquez","bagnaia","martin","quartararo","acosta","binder","bastianini","zarco","ducati","yamaha","honda","ktm","aprilia"],spoilerTerms:F,safeTerms:G,regexes:_},p=["wins","won","winner","beat","beats","beaten","defeat","defeats","defeated","lose","loses","lost","draw","drew","equaliser","penalty shootout","knocked out","stunned","comeback","injury-time","stoppage-time","late winner","last-minute winner","full-time","ft","score","result","promoted","relegated","title"],m=["preview","fixtures","fixture","schedule","what time","watch","team news","line-ups","lineups"],i=["\\b\\d{1,2}\\s*[-–:]\\s*\\d{1,2}\\b"],ae={id:"football",label:"General football",group:"Football",description:"General football headlines and score/result language.",entities:["football","fa cup","league cup","carabao cup","world cup","euros","euro 2028","uefa","fifa"],spoilerTerms:p,safeTerms:m,regexes:i},ie={id:"premier-league",label:"Premier League",group:"Football",description:"Premier League clubs and results.",entities:["premier league","arsenal","aston villa","bournemouth","brentford","brighton","burnley","chelsea","crystal palace","everton","fulham","leeds united","liverpool","manchester city","man city","manchester united","man utd","newcastle united","nottingham forest","sunderland","tottenham","spurs","west ham","wolves","wolverhampton wanderers"],spoilerTerms:p,safeTerms:m,regexes:i},le={id:"championship",label:"Championship",group:"Football",description:"EFL Championship clubs and results.",entities:["championship","efl championship","birmingham city","blackburn rovers","bristol city","charlton athletic","coventry city","sky blues","derby county","hull city","ipswich town","leicester city","middlesbrough","millwall","norwich city","portsmouth","preston north end","qpr","queens park rangers","sheffield united","sheffield wednesday","southampton","stoke city","swansea city","watford","west brom","west bromwich albion","wrexham"],spoilerTerms:p,safeTerms:m,regexes:i},ce={id:"champions-league",label:"Champions League",group:"Football",description:"UEFA Champions League results and knockout stories.",entities:["champions league","uefa champions league","ucl","real madrid","barcelona","bayern munich","borussia dortmund","psg","paris saint-germain","inter milan","ac milan","juventus","benfica","porto","ajax","atletico madrid","sporting cp"],spoilerTerms:p,safeTerms:m,regexes:i},de={id:"england-football",label:"England football",group:"Football",description:"England men's and women's national football results.",entities:["england","england football","three lions","lionesses","euro 2028","world cup qualifier","nations league"],spoilerTerms:p,safeTerms:m,regexes:i},ue={id:"coventry-city",label:"Coventry City",group:"Football",description:"Coventry City and Sky Blues results.",entities:["coventry city","coventry","sky blues","ccfc"],spoilerTerms:p,safeTerms:m,regexes:i},x=["wins","won","winner","beat","beats","beaten","defeat","defeats","defeated","lose","loses","lost","draw","drawn","all out","wickets","runs","century","hat-trick","collapse","chase","series win","ashes win"],v=["preview","schedule","what time","watch","squad","team news","fixtures"],T=["\\b\\d{2,3}-\\d\\b","\\b\\d{2,3}/\\d\\b","\\bwon by \\d+ (runs|wickets)\\b"],pe={id:"cricket",label:"Cricket",group:"Cricket",description:"General cricket results and score spoilers.",entities:["cricket","test match","odi","t20","t20i","world cup","county championship","the hundred"],spoilerTerms:x,safeTerms:v,regexes:T},me={id:"england-cricket",label:"England cricket",group:"Cricket",description:"England cricket results across formats.",entities:["england cricket","england","ben stokes","joe root","jos buttler","jofra archer","harry brook","ollie pope","mark wood"],spoilerTerms:x,safeTerms:v,regexes:T},fe={id:"ashes",label:"The Ashes",group:"Cricket",description:"Ashes Test series spoilers.",entities:["ashes","the ashes","england","australia","baggy greens","test match"],spoilerTerms:x,safeTerms:v,regexes:T},S=["wins","won","winner","beats","beat","defeats","defeated","loses","lost","knocked out","crashes out","through to","reaches final","wins title","champion","straight sets","five-set","retired","walkover"],A=["preview","schedule","what time","watch","order of play","draw","seedings"],R=["\\b\\d{1,2}-\\d{1,2}\\s+\\d{1,2}-\\d{1,2}\\b","\\b\\d{1,2}-\\d{1,2}\\s+\\d{1,2}-\\d{1,2}\\s+\\d{1,2}-\\d{1,2}\\b"],ge={id:"tennis",label:"Tennis",group:"Tennis",description:"General tennis results and tournament spoilers.",entities:["tennis","atp","wta","djokovic","alcaraz","sinner","nadal","federer","swiatek","sabalenka","gauff","raducanu","murray","british number one"],spoilerTerms:S,safeTerms:A,regexes:R},be={id:"wimbledon",label:"Wimbledon",group:"Tennis",description:"Wimbledon results and draw spoilers.",entities:["wimbledon","all england club","centre court","no 1 court","ladies' singles","gentlemen's singles"],spoilerTerms:S,safeTerms:A,regexes:R},he={id:"grand-slams",label:"Grand Slams",group:"Tennis",description:"Grand Slam tennis tournaments.",entities:["grand slam","australian open","french open","roland garros","wimbledon","us open"],spoilerTerms:S,safeTerms:A,regexes:R},E=["wins","won","winner","beat","beats","beaten","defeat","defeats","defeated","lose","loses","lost","draw","try","tries","conversion","penalty","drop goal","grand slam","triple crown","wooden spoon","score","result"],z=["preview","fixtures","schedule","what time","watch","team news","squad"],ye={id:"rugby-union",label:"Rugby union",group:"Rugby",description:"General rugby union result spoilers.",entities:["rugby union","rugby","premiership rugby","urc","united rugby championship","champions cup","world cup"],spoilerTerms:E,safeTerms:z,regexes:i},we={id:"six-nations",label:"Six Nations",group:"Rugby",description:"Six Nations and international rugby results.",entities:["six nations","guinness six nations","england rugby","wales rugby","scotland rugby","ireland rugby","france rugby","italy rugby","grand slam","triple crown"],spoilerTerms:E,safeTerms:z,regexes:i},ke={id:"rugby-league",label:"Rugby league",group:"Rugby",description:"General rugby league result spoilers.",entities:["rugby league","super league","challenge cup","wigan warriors","st helens","leeds rhinos","warrington wolves","hull kr","catalans dragons"],spoilerTerms:E,safeTerms:z,regexes:i},j=["wins","won","winner","beat","beats","beaten","defeat","defeats","defeated","lose","loses","lost","overtime","playoffs","playoff","super bowl","finals","championship","clinches","eliminated","score","result"],q=["preview","schedule","what time","watch","fixtures","draft","trade rumours","trade rumors"],N=["\\b\\d{1,3}\\s*[-–:]\\s*\\d{1,3}\\b"],xe=Object.fromEntries([oe,ne,ae,ie,le,ce,de,ue,ye,we,ke,pe,me,fe,ge,be,he,{id:"nfl",label:"NFL",group:"US sports",description:"NFL results, playoffs, and Super Bowl spoilers.",entities:["nfl","super bowl","american football","chiefs","eagles","cowboys","packers","patriots","ravens","49ers","niners","bills","dolphins","steelers"],spoilerTerms:j,safeTerms:q,regexes:N},{id:"nba",label:"NBA",group:"US sports",description:"NBA results, playoffs, and Finals spoilers.",entities:["nba","basketball","nba finals","lakers","celtics","warriors","bulls","knicks","heat","nuggets","bucks","mavericks","suns"],spoilerTerms:j,safeTerms:q,regexes:N}].map(e=>[e.id,e]));function ve(e){return e.map(t=>xe[t]).filter(Boolean)}const b={catchUpMode:{enabled:!1,sensitivity:"lockdown"},enabledPacks:["f1"],customTerms:[],trustedSites:[]},I="despoilerze.settings";async function B(){const t=(await chrome.storage.sync.get(I))[I];return{...b,...t,catchUpMode:{...b.catchUpMode,...t?.catchUpMode??{}},enabledPacks:t?.enabledPacks??b.enabledPacks,customTerms:t?.customTerms??b.customTerms,trustedSites:t?.trustedSites??b.trustedSites}}function C(e,t=new Date){return e.catchUpMode.enabled?e.catchUpMode.expiresAtUtc?new Date(e.catchUpMode.expiresAtUtc)>t:!0:!1}const Te={gentle:9,balanced:6,lockdown:3};function O(e){return e.toLowerCase().replace(/[‘’]/g,"'").replace(/[“”]/g,'"').replace(/[–—]/g,"-").replace(/\s+/g," ").trim()}function h(e,t){const r=O(t);if(!r)return!1;const o=r.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");return new RegExp(`(^|[^a-z0-9])${o}([^a-z0-9]|$)`,"i").test(e)}function Se(e,t,r,o=[]){const s=O(e),a=[],c=[];let d=0;if(!s||s.length<3)return{shouldHide:!1,score:0,packIds:[],reasons:[],sensitivity:r};for(const n of t){const re=n.entities.filter(u=>h(s,u)),D=n.spoilerTerms.filter(u=>h(s,u)),se=n.safeTerms.filter(u=>h(s,u)),Qe=n.regexes.filter(u=>new RegExp(u,"i").test(s));if(re.length===0)continue;let g=0;g+=r==="lockdown"?4:3,a.push(`${n.label}: entity match (${re.slice(0,3).join(", ")})`),D.length>0&&(g+=D.length>=2?6:5,a.push(`${n.label}: spoiler wording (${D.slice(0,3).join(", ")})`)),Qe.length>0&&(g+=6,a.push(`${n.label}: result-like pattern`)),se.length>0&&r!=="lockdown"&&(g-=2,a.push(`${n.label}: possible safe context (${se.slice(0,2).join(", ")})`)),g>0&&(c.push(n.id),d+=g)}const te=o.filter(n=>h(s,n));return te.length>0&&(d+=r==="lockdown"?4:3,a.push(`Custom term match (${te.slice(0,3).join(", ")})`)),{shouldHide:d>=Te[r],score:d,packIds:c,reasons:a,sensitivity:r}}const W="despoilerze-shell",P="despoilerze-wrapper",L="despoilerze-blurred",M="despoilerze-overlay",V="data-despoilerze-processed",y="data-despoilerze-hidden",$="data-despoilerze-shell",f="data-despoilerze-target-id",Y="data-despoilerze-detached-overlay",Ae="data-despoilerze-revealed";let Re=1;function Ee(){if(document.getElementById("despoilerze-style"))return;const e=document.createElement("style");e.id="despoilerze-style",e.textContent=`
    .${W} {
      display: block !important;
      width: 100% !important;
      max-width: 100% !important;
      box-sizing: border-box !important;
      margin: 0 !important;
      padding: 0 !important;
    }

    .${P} {
      outline: 2px solid rgba(255, 255, 255, 0.22) !important;
      border-radius: 8px !important;
      overflow: hidden !important;
    }

    .${L} {
      filter: blur(10px) !important;
      user-select: none !important;
      pointer-events: none !important;
    }

    .${M} {
      display: block !important;
      position: static !important;
      z-index: 2147483647 !important;
      pointer-events: auto !important;
      padding: 0 !important;
      margin: 0 0 8px 0 !important;
      box-sizing: border-box !important;
      color: #fff !important;
      font-family: system-ui, -apple-system, Segoe UI, sans-serif !important;
      text-align: left !important;
      transform: none !important;
      filter: none !important;
      direction: ltr !important;
      writing-mode: horizontal-tb !important;
    }

    .despoilerze-detached-overlay {
      position: absolute !important;
      z-index: 2147483647 !important;
      display: block !important;
      pointer-events: auto !important;
      padding: 0 !important;
      margin: 0 !important;
      box-sizing: border-box !important;
      transform: none !important;
      filter: none !important;
      direction: ltr !important;
      writing-mode: horizontal-tb !important;
      text-align: left !important;
      color: #fff !important;
      font-family: system-ui, -apple-system, Segoe UI, sans-serif !important;
    }

    .despoilerze-card {
      display: inline-block !important;
      max-width: min(360px, 100%) !important;
      background: rgba(0, 0, 0, 0.88) !important;
      border: 1px solid rgba(255,255,255,0.28) !important;
      border-radius: 8px !important;
      padding: 10px 12px !important;
      box-shadow: 0 6px 20px rgba(0,0,0,0.35) !important;
      box-sizing: border-box !important;
      color: #fff !important;
    }

    .despoilerze-title {
      font-weight: 700 !important;
      margin-bottom: 4px !important;
      font-size: 14px !important;
      line-height: 1.25 !important;
      color: #fff !important;
    }

    .despoilerze-reason {
      font-size: 12px !important;
      line-height: 1.35 !important;
      opacity: 0.85 !important;
      margin-bottom: 8px !important;
      color: #fff !important;
    }

    .despoilerze-button {
      appearance: none !important;
      border: 1px solid rgba(255,255,255,0.35) !important;
      border-radius: 5px !important;
      padding: 4px 8px !important;
      background: rgba(255,255,255,0.12) !important;
      color: #fff !important;
      cursor: pointer !important;
      font-size: 12px !important;
      line-height: 1.2 !important;
      margin: 0 6px 0 0 !important;
    }

    .despoilerze-button:hover {
      background: rgba(255,255,255,0.24) !important;
    }
  `,document.documentElement.appendChild(e)}function w(e){e.setAttribute(V,"true")}function ze(e){return e.getAttribute(V)==="true"}function Z(e){return e.getAttribute(y)==="true"||!!e.closest(`[${$}="true"]`)}function Ce(e,t){if(Z(e)||!e.parentElement)return;if(Ee(),Me()){Pe(e,t);return}const r=document.createElement("div");r.className=W,r.setAttribute($,"true");const o=K(e,t);e.parentElement.insertBefore(r,e),r.appendChild(o),r.appendChild(e),Q(e,t)}function Pe(e,t){const r=$e(e),o=K(e,t);o.classList.add("despoilerze-detached-overlay"),o.setAttribute(Y,"true"),o.setAttribute(f,r),Le(o,e),document.body.appendChild(o),Q(e,t)}function K(e,t){const r=document.createElement("div");return r.className=M,r.innerHTML=`
    <div class="despoilerze-card">
      <div class="despoilerze-title">Possible sports result hidden</div>
      <div class="despoilerze-reason">${Ue(t.reasons[0]??"Catch-up Mode is active")}</div>
      <button class="despoilerze-button" data-action="reveal-once">Reveal once</button>
      <button class="despoilerze-button" data-action="reveal-all">Reveal all on page</button>
    </div>
  `,r.addEventListener("click",o=>{o.stopPropagation();const s=o.target;if(!(s instanceof HTMLElement))return;const c=s.closest("button[data-action]")?.getAttribute("data-action");if(c==="reveal-once"){X(e);return}c==="reveal-all"&&J()}),r}function Q(e,t){e.classList.add(P,L),e.setAttribute(y,"true"),e.setAttribute("data-despoilerze-score",String(t.score)),e.setAttribute("data-despoilerze-reasons",t.reasons.join(" | "))}function Le(e,t){const r=t.getBoundingClientRect(),o=Math.max(0,r.top+window.scrollY+8),s=Math.max(0,r.left+window.scrollX+8);e.style.top=`${o}px`,e.style.left=`${s}px`,e.style.maxWidth=`${Math.max(220,Math.min(360,r.width-16))}px`}function Me(){return/(^|\.)google\./i.test(window.location.hostname)&&window.location.pathname==="/search"}function $e(e){const t=e.getAttribute(f);if(t)return t;const r=`despoilerze-target-${Re++}`;return e.setAttribute(f,r),r}function X(e){const t=e.closest(`[${$}="true"]`),r=e.getAttribute(f);if(e.setAttribute(Ae,"true"),e.classList.remove(P,L),e.removeAttribute(y),r){for(const o of Array.from(document.querySelectorAll(`[${Y}="true"][${f}="${r}"]`)))o.remove();e.removeAttribute(f)}if(t?.parentElement){t.parentElement.insertBefore(e,t),t.remove();return}for(const o of Array.from(e.querySelectorAll(`.${M}`)))o.remove()}function J(){for(const e of Array.from(document.querySelectorAll(`[${y}="true"]`)))X(e)}function Ue(e){return e.replace(/[&<>"']/g,t=>{switch(t){case"&":return"&amp;";case"<":return"&lt;";case">":return"&gt;";case'"':return"&quot;";case"'":return"&#039;";default:return t}})}const ee=["article","h1","h2","h3","h4","[role='article']","[data-testid*='post']","[data-testid*='card']","[class*='promo']","[class*='media']","[id='video-title']","[id='video-title-link']","ytd-rich-item-renderer","ytd-rich-grid-media","ytd-video-renderer","ytd-compact-video-renderer","ytd-grid-video-renderer","ytd-reel-item-renderer","ytd-reel-video-renderer","yt-lockup-view-model","ytm-shorts-lockup-view-model"],He=["article","[role='article']","[data-testid*='post']","[data-testid*='card']","ytd-rich-item-renderer","ytd-rich-grid-media","ytd-video-renderer","ytd-compact-video-renderer","ytd-grid-video-renderer","ytd-reel-item-renderer","ytd-reel-video-renderer","yt-lockup-view-model","ytm-shorts-lockup-view-model","li",".card",".promo",".media",".gs-result",".g"],De=[".MjjYud",".hlcw0c",".Ww4FFb",".g",".rc"],Fe=["nav","header","footer","form","button","select","textarea","input","[role='navigation']","[role='banner']","[role='search']","[role='menubar']","[role='menu']","[aria-label*='breadcrumb' i]","[class*='breadcrumb' i]","[class*='navbar' i]","[class*='nav-' i]","[class*='masthead' i]","#masthead","ytd-masthead","tp-yt-paper-dialog"];function Ge(e,t,r=document){if(!C(e)||Ye(e))return;const o=_e(r);for(const s of o){if(!(s instanceof HTMLElement)||ze(s)||Z(s))continue;if(k(s)){w(s);continue}if(!Ve(s))continue;if(s.closest("[data-despoilerze-hidden='true'], [data-despoilerze-shell='true'], [data-despoilerze-revealed='true']")){w(s);continue}const a=Oe(s);if(!We(a)){w(s);continue}const c=Se(a,t,e.catchUpMode.sensitivity,e.customTerms);if(c.shouldHide){const d=je(s);!d.closest("[data-despoilerze-hidden='true'], [data-despoilerze-shell='true'], [data-despoilerze-revealed='true']")&&!k(d)&&Ce(d,c)}w(s)}}function _e(e){const t=new Set;e instanceof Element&&Be(e,ee)&&t.add(e);for(const r of ee)e.querySelectorAll?.(r).forEach(o=>t.add(o));return Array.from(t)}function je(e){if(Ie()){const t=qe(e);if(t)return t}for(const t of He){const r=e.closest(t);if(r instanceof HTMLElement&&!k(r))return r}return e}function qe(e){for(const t of De){const r=e.closest(t);if(r instanceof HTMLElement&&Ne(r))return r}return null}function Ne(e){if(k(e))return!1;const t=e.getBoundingClientRect();if(t.width<120||t.height<40)return!1;const r=Math.max(document.documentElement.clientHeight,window.innerHeight||0);return!(t.height>r*.8)}function Ie(){return/(^|\.)google\./i.test(window.location.hostname)&&window.location.pathname==="/search"}function Be(e,t){return t.some(r=>{try{return e.matches(r)}catch{return!1}})}function Oe(e){const t=e.getAttribute("aria-label")??"",r=e.getAttribute("title")??"",o=e.innerText??e.textContent??"";return`${t} ${r} ${o}`.replace(/\s+/g," ").trim()}function We(e){return!e||e.length<4||e.length>500?!1:/[a-zA-Z]/.test(e)}function Ve(e){const t=window.getComputedStyle(e);if(t.display==="none"||t.visibility==="hidden"||t.opacity==="0")return!1;const r=e.getBoundingClientRect();return r.width>20&&r.height>10}function k(e){return Fe.some(t=>{try{return!!e.closest(t)}catch{return!1}})}function Ye(e){const t=window.location.hostname.toLowerCase();return e.trustedSites.some(r=>t===r.toLowerCase()||t.endsWith(`.${r.toLowerCase()}`))}let l=null,U=!1;async function Ze(){if(l=await B(),!C(l))return;H(),new MutationObserver(t=>{if(!l||!C(l))return;const r=[];for(const o of t)for(const s of Array.from(o.addedNodes))(s instanceof Element||s instanceof DocumentFragment)&&r.push(s);r.length>0&&Ke(r)}).observe(document.body,{childList:!0,subtree:!0})}function H(e=[document]){if(!l)return;const t=ve(l.enabledPacks);for(const r of e)Ge(l,t,r)}function Ke(e=[document]){U||(U=!0,window.setTimeout(()=>{U=!1,H(e)},250))}chrome.runtime.onMessage.addListener((e,t,r)=>((async()=>{if(e?.type==="DESPOILERZE_SETTINGS_CHANGED"){l=await B(),H(),r({ok:!0});return}if(e?.type==="DESPOILERZE_REVEAL_ALL"){J(),r({ok:!0});return}r({ok:!1})})(),!0)),Ze()})();
